./gpu-4th | tee log.4th.1st
./gpu-4th | tee log.4th.2nd
./gpu-6th | tee log.6th.1st
./gpu-6th | tee log.6th.2nd
./gpu-8th | tee log.8th.1st
./gpu-8th | tee log.8th.2nd
